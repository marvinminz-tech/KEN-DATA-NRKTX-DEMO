

## Plan: Enhance Editable Cell Visual Distinction (Options 1 + 3)

### Changes

**`src/index.css`** — Update grid cell styles:
- **Editable cells**: White background with a subtle blue tint (`bg-blue-50/60`), and a dotted bottom border on the text to simulate an inline form field
- **Read-only cells**: Keep current muted grey, no underline
- **Past cells**: Keep current darker grey
- **Hover on editable**: Slightly stronger blue tint (`bg-blue-100/50`)

**`src/pages/PlanningGrid.tsx`** — Minor markup update:
- Wrap editable cell values in a `<span>` with a dotted underline style so the underline only appears under the text, not the full cell width

### CSS Updates (index.css)
```css
.grid-cell-editable {
  @apply bg-blue-50/60 cursor-text;
}
.grid-cell-editable:hover {
  @apply bg-blue-100/50;
}
/* Add dotted underline span inside editable cells */
.grid-cell-editable .cell-value {
  border-bottom: 1px dotted hsl(var(--primary) / 0.4);
  padding-bottom: 1px;
}
```

### Rendering Update (PlanningGrid.tsx)
- In `renderCell`, wrap the formatted value output in `<span className="cell-value">` for editable cells only
- Read-only and past cells render the value without the wrapper

